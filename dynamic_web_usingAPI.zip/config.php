<?php
    $config['base_url'] = ""
?>